package com.jiangyu.common.entity;

public class StaticEntity {


    public DataBean data;
    public String code;
    public String msg;

    public static class DataBean {


        public String logo_url;
        public String service_protocol_url_ios;
        public String service_qq;
        public String service_tel;
        public String download_url;
        public String about_us_url;
        public String kefu_url;
        public String kefu_url_ios;
        public String share_content;
        public String service_protocol_url;
        public String send_money;
        public String user_guide_url;
        public String service_time;
        public String share_title;
        public String recharge_money;
        public String common_problem;
    }
}
